# NOTICE 06.01.2024
- Just updated readme, all info you need
- If there is any news I will update the readme immediately
- May this holiday season brighten you up with happiness, joy and good cheer!

# WANNA ASK ME SOMETHING OR YOU NEED HELP?
Use "Discussions tab", instead of "Issues"!

# CURRENT STATUS
- 7.0ver. ARM - FULL WORK! x86/x64 - WAITING CRACK
- 6.6ver x86/x64 - WORK 

# GUIDE FOR LITTLE ONES ONLY FOR 6.6ver. x64/x86 CRACK
YT blocks so i have uploaded to mega cloud
- FIRST VIDEO GUIDE [First guide](https://mega.nz/file/AP51BQIQ#bwNmDOsiPYGk0O03H-tSc5ObuOzVtgb58ddTKqWQGlk)
- SECOND VIDEO GUIDE(FOR NOOBS) [Second guide](https://mega.nz/file/tTYGWZiB#LA9Sr4kOIswYFSf51fuN4wg88qOIQjaY_Y-B-4qNzM8)

# TEXT GUIDE 
1. Extract the files from the archive to the folder with reSENSI
2. Change 4 paths in the file "1337_NI66A_PUSSYSLAYER_BREAKPOINT.xml". 
"C:\Program Files\reSENSI\reSENSIEngine.exe" to your path
3. Launch dnSpy.exe and drop reSENSIEngine.exe into dnSpy
4. Add breapoint window in dnSpy ->Debug->Windows->Breakpoints
5. Import "1337_NI66A_PUSSYSLAYER_BREAKPOINT.xml" with special button in breapoint window
6. You should see 4 breakpoints, if there are less than 4 then you have done something wrong.
7. Launch reSENSIEngine.exe(not reSENSI.exe) only from dnSpy!!!!
8. Close reSENSI only from tray windows and then close dnSpy

# Applying config and nothing happens? 6.6 ver.
FIRSTLY, CHECK CLOSED ISSUES AND TWO VIDEO GUIDES, USE DISCUSSIONS TO ASK ME, TAKE CARE OF YOUR AND MY TIME❤️

Most likely, you have not imported breakpoints
- There may be two reasons why they are not imported:
1. You need to select the current assembly in dnSpy, that is, click on reSENSIEngine in Assembly editor, I did it in the video at 2:15.
2. Change the paths to the file reSENSIEngine.exe in the file with breakpoints (1337_pus...xml), there are only 4 lines where you need to set the correct path to the file, in the video it is 1:46 minute (also in the video there is only 1 path because today the fix came out and now there are 4)

# Everything was working for a few days and suddenly an error? (XamlReader.WrapException....)
Defender killed some reSENSI files (that you moved from archive to folder), add reSENSI folder or reSENSI files to defender (or your antivirus) whitelist.
![Screenshot](https://github.com/EugeneSunrise/reSENSI/assets/56397706/3a5da084-68e6-41a0-b477-b735840ed18b)

# Startup automation for dnSpy
Use autohotkey, make a simple file including lines below, and move it to startup folder, then it can be automaticly run when You start PC and placed in tray menu:
- Run, D:\reSENSI1\dnSpy-net-win32\dnSpy.exe
- Sleep 3000
- Send {F5}
- Sleep 2000
- Send {Enter}
- Sleep 1000
- Winhide dnSpy

# Special Thanks
- HUGE THANKS TO [Eddy](https://github.com/RedDot-3ND7355) ([reSENSI](https://github.com/RedDot-3ND7355/reSENSI)) ONLY THANKS TO HIM YOU CAN USE X64/86 VERSION FOR FREE, SO BEFORE DOWNLOADING GO TO HIS GITHUB PROFILE AND PUT STARS ON EACH OF HIS PROJECTS!!!!
- Read below if the config doesn't work. ALSO BIG CREDITS TO [Lucas](https://github.com/lukasbrauneruv) for providing the Zoom's 50$ - "The Finals" [CONFIG](https://drive.google.com/file/d/15L47Oa1uzCqDQ7sjSoOhhp4yOp156paC/view)(AimAssist+Recoil):
"It has some recoil configs for different weapons. F5 stops/start the script and 5 6 7 8 are different weapon recoil setups. Also here is a picture of recommended controller settings for maximum aimassist"
![recommended controller settings](https://github.com/EugeneSunrise/reSENSI/assets/56397706/5320c8e1-9807-4e65-883a-caf602e0a57c)
- Thanks to [Whiz](https://github.com/Time2Whizard) for the provided bypass AC:
"The AC is Blocking reSENSI itself, funnily reSENSI works even disabled. Simply start the script enable toggle for mouse move and exit reSENSI from the tray icon. This will bypass the reSENSI Controller input detection." [Tutorial](https://drive.google.com/uc?id=1IldJzkJ6oYrbYXK2WKYmceFMtP8eZGeW&export=download)

# Antivirus says there are trojans in the files? // Trojan:Win32/Znyonm
Quick answer - it's false positive, if you don't trust it so don't download it.
In the archive is dnSpy - a program for reversing .net applications, it is scolded by antivirus also the other files have no signature, so it can also be a red factor for antivirus. You can download dnSpy from the official repository on github (and configure it yourself). If you still think I'm trying to plant a trojan and upload hentai to your PC so just don't download the crack and don't bother me.

# reSENSI Source Code & Patched Lib's in Releases
![Screenshot 29-11-2023 at 22-15-35](https://github.com/EugeneSunrise/reSENSI/assets/56397706/1d3e6290-73b2-4d19-a826-17667841aaed)


# USING. ITS ONLY FOR 7.0 VER. ARM(x86 dont work right now)
reSENSI has are several versions, the version for Windows x86/x64 and Windows ARM Architecture.

Step by step for the littlest ones:
- First of all, delete your current version of reSENSI program
- Go to [Releases](https://github.com/EugeneSunrise/reSENSI/releases) and pick your version
- Do you see the Assets tab? Fine!
- Download installer in Assets for cracked version - reSENSI700-8378(ARM).exe or reSENSI700-8447.exe
- Install!
- Download reSENSI.dll and reSENSICommon.dll(or reSENSIEngine.dll for ARM) in Assets
- Disable reSENSI (if enabled)
- Move reSENSI.dll and reSENSICommon.dll( or reSENSIEngine.dll) WITH REPLACEMENT in main reSENSI folder
- Start reSENSI, all features are available!


## Support the project 

Put "star" on this project or if you want to help with money:

TRX(Tron): TGztJ8FSwKNSrigESddGq6euHa9UgtkujG

BTC(Bitcoin): bc1q9ym4ac67x9c2slg64lq3u8wczdadj4tep7y2fw

ETH(Ethereum): 0xb9Fa2B5661238eC9D825bdb0379Db5b035179282

**Thanks for the support!**

