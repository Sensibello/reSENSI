﻿using System;
using System.Collections.Generic;

namespace reSENSIEngine.Services.HttpServer.SystemMonitor
{
	public delegate void LockedKeysChanged(HashSet<int> keys);
}
