﻿using System;

namespace reSENSIEngine.Services.HttpServer.SystemMonitor
{
	public delegate void InputLocaleIdChanged(uint newLocaleId);
}
