﻿using System;

namespace reSENSIEngine.Services.UdpServer.Input
{
	internal struct KeyboardData
	{
		public byte[] Keys;
	}
}
