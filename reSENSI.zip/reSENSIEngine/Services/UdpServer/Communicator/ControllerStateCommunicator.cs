﻿using System;

namespace reSENSIEngine.Services.UdpServer.Communicator
{
	internal class ControllerStateCommunicator
	{
	}
}
