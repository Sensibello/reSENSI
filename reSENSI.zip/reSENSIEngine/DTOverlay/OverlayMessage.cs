﻿using System;

namespace DTOverlay
{
	internal class OverlayMessage
	{
		public const int WM_HOTKEY = 786;

		public const int WM_APP = 32768;

		public const int overlayMessage = 32769;
	}
}
