﻿using System;

namespace DTOverlay
{
	public class HashInfo
	{
		public long Hash;

		public long GyroXDelta;

		public long GyroYDelta;

		public long GyroZDelta;

		public long AccelXDelta;

		public long AccelYDelta;

		public long AccelZDelta;
	}
}
