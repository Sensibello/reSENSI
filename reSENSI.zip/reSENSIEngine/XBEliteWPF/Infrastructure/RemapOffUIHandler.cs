﻿using System;

namespace XBEliteWPF.Infrastructure
{
	public delegate void RemapOffUIHandler(string ID, string deviceName);
}
