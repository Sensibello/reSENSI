﻿using System;
using DiscSoft.NET.Common.Utils.Clases;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class PhysSlot3Selected : PubSubEvent<WindowMessageEvent>
	{
	}
}
