﻿using System;
using XBEliteWPF.Infrastructure.Controller;

namespace XBEliteWPF.Infrastructure
{
	public delegate void OffileDeviceHandle(BaseControllerVM controller);
}
