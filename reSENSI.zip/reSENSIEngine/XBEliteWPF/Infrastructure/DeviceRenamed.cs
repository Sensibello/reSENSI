﻿using System;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class DeviceRenamed : PubSubEvent<string>
	{
	}
}
