﻿using System;
using DiscSoft.NET.Common.Utils.Clases;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class ProfilesChanged : PubSubEvent<WindowMessageEvent>
	{
	}
}
