﻿using System;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class PreferencesChanged : PubSubEvent<object>
	{
	}
}
