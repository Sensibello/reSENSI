﻿using System;
using XBEliteWPF.Infrastructure.Controller;

namespace XBEliteWPF.Infrastructure
{
	public delegate void SetBatteryNotificationEventHandler(BaseControllerVM controller);
}
