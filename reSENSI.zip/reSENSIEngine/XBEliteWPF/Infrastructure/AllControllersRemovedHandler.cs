﻿using System;

namespace XBEliteWPF.Infrastructure
{
	public delegate void AllControllersRemovedHandler();
}
