﻿using System;
using DiscSoft.NET.Common.Utils.Clases;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class PhysSlot4Selected : PubSubEvent<WindowMessageEvent>
	{
	}
}
