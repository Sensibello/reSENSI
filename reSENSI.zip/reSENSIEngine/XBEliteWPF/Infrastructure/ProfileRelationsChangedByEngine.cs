﻿using System;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class ProfileRelationsChangedByEngine : PubSubEvent<object>
	{
	}
}
