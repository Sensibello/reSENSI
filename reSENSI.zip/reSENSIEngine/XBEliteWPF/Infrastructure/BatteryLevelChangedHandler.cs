﻿using System;
using XBEliteWPF.Infrastructure.Controller;

namespace XBEliteWPF.Infrastructure
{
	public delegate void BatteryLevelChangedHandler(ControllerVM controller);
}
