﻿using System;

namespace XBEliteWPF.Infrastructure
{
	public delegate void ShiftHideHandlerUI(string ID);
}
