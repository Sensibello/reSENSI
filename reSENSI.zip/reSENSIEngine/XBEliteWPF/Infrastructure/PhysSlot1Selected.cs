﻿using System;
using DiscSoft.NET.Common.Utils.Clases;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class PhysSlot1Selected : PubSubEvent<WindowMessageEvent>
	{
	}
}
