﻿using System;
using System.Windows.Input;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class KeyboardKeyReleased : PubSubEvent<Key>
	{
	}
}
