﻿using System;

namespace XBEliteWPF.Infrastructure
{
	public delegate void GamepadRemapEventHandler(string ID, string ControllerDisplayName);
}
