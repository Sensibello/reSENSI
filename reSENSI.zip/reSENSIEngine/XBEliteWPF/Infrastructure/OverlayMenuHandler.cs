﻿using System;

namespace XBEliteWPF.Infrastructure
{
	public delegate void OverlayMenuHandler(string ID, string controllerDisplayName, string gameName, string profileName);
}
