﻿using System;

namespace XBEliteWPF.Infrastructure
{
	public delegate void MappingHotkeyHandler(string ID, string controllerDisplayName, string gameName, string profileName, bool isDescriptions);
}
