﻿using System;
using Prism.Events;

namespace XBEliteWPF.Infrastructure
{
	public class PresetsFolderChanged : PubSubEvent<string>
	{
	}
}
