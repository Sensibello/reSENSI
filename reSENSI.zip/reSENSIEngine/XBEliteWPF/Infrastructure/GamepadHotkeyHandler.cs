﻿using System;

namespace XBEliteWPF.Infrastructure
{
	public delegate void GamepadHotkeyHandler(string ID, string controllerDisplayName, string gameName, string profileName);
}
