﻿using System;

namespace reSENSIEngine.OverlayAPI.RemapWindow
{
	public enum CreationRemapStyle
	{
		NormalCreation,
		BlackWhitePrint,
		ColorPrint
	}
}
