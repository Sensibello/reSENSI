﻿using System;

namespace reSENSIEngine
{
	internal static class Program
	{
		[STAThread]
		private static void Main()
		{
			new Engine().Run();
		}
	}
}
