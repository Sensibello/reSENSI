﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;

[assembly: AssemblyVersion("6.7.0.8034")]
[assembly: AssemblyTitle("reSENSI: gamepad mapper resources")]
[assembly: AssemblyDescription("reSENSI: gamepad mapper resources")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Disc Soft FZE LLC")]
[assembly: AssemblyProduct("reSENSI Engine")]
[assembly: AssemblyCopyright("© 2016-2023 Disc Soft FZE LLC.")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyFileVersion("6.7.0.8034")]
