﻿using System;

namespace reSENSICommandLine
{
	public static class Utils
	{
		public static void OutputText(string txt)
		{
			Console.WriteLine(txt);
		}
	}
}
