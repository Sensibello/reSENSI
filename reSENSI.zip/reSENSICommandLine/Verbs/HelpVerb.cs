﻿using System;
using CommandLine;

namespace reSENSICommandLine.Verbs
{
	[Verb("help", false, HelpText = "Display this help.\nExample: reSENSICommandLine.exe help")]
	internal class HelpVerb
	{
	}
}
