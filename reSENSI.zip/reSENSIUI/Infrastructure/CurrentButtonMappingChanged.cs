﻿using System;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class CurrentButtonMappingChanged : PubSubEvent<object>
	{
	}
}
