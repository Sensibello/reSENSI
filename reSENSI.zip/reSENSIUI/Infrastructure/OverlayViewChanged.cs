﻿using System;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class OverlayViewChanged : PubSubEvent<object>
	{
	}
}
