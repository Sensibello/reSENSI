﻿using System;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class OnNavigateRequest : PubSubEvent<object>
	{
	}
}
