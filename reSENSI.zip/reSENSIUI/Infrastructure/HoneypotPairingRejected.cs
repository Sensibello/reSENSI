﻿using System;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class HoneypotPairingRejected : PubSubEvent<ulong>
	{
	}
}
