﻿using System;
using Prism.Events;
using reSENSIUI.Infrastructure.KeyBindings.XBBindingDirectionalGroups;

namespace reSENSIUI.Infrastructure
{
	public class RequestRefreshAnnotationVisibilityForGroup : PubSubEvent<BaseDirectionalGroup>
	{
	}
}
