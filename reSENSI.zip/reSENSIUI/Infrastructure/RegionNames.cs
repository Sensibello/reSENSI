﻿using System;

namespace reSENSIUI.Infrastructure
{
	public class RegionNames
	{
		public static string Sidebar = "Sidebar";

		public static string Content = "Content";

		public static string BindingFrame = "BindingFrame";

		public static string Gamepad = "Gamepad";
	}
}
