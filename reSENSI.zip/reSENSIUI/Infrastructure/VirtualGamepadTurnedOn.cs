﻿using System;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class VirtualGamepadTurnedOn : PubSubEvent<object>
	{
	}
}
