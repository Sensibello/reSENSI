﻿using System;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class CloseAllPopups : PubSubEvent<object>
	{
	}
}
