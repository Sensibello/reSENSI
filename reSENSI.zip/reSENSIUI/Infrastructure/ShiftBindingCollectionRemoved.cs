﻿using System;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class ShiftBindingCollectionRemoved : PubSubEvent<object>
	{
	}
}
