﻿using System;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class GyroCalibrationFinished : PubSubEvent<string>
	{
	}
}
