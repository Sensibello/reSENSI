﻿using System;
using System.Windows.Input;
using Prism.Events;

namespace reSENSIUI.Infrastructure
{
	public class KeyboardKeyReleased : PubSubEvent<Key>
	{
	}
}
