﻿using System;

namespace reSENSIUI.Utils
{
	internal class DoNotCacheViewAttribute : Attribute
	{
	}
}
