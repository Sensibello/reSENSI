﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace reSENSIUI.Controls
{
	public partial class UnmapControl : UserControl
	{
		public UnmapControl()
		{
			this.InitializeComponent();
		}
	}
}
