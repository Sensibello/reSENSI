﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Method)]
	public sealed class LinqTunnelAttribute : Attribute
	{
	}
}
