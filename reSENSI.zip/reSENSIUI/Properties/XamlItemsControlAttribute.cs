﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Class)]
	public sealed class XamlItemsControlAttribute : Attribute
	{
	}
}
