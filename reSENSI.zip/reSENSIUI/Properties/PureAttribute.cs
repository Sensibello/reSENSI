﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Method)]
	public sealed class PureAttribute : Attribute
	{
	}
}
