﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcMasterAttribute : Attribute
	{
	}
}
