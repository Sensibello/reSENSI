﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Property)]
	public sealed class XamlItemBindingOfItemsControlAttribute : Attribute
	{
	}
}
