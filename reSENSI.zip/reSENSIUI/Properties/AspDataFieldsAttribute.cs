﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Property)]
	public sealed class AspDataFieldsAttribute : Attribute
	{
	}
}
