﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Interface)]
	public sealed class ImplicitNotNullAttribute : Attribute
	{
	}
}
