﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Method)]
	public sealed class RazorHelperCommonAttribute : Attribute
	{
	}
}
