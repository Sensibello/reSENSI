﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Parameter)]
	public sealed class AspMvcModelTypeAttribute : Attribute
	{
	}
}
