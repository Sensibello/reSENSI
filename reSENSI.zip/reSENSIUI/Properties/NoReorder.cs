﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.All)]
	public sealed class NoReorder : Attribute
	{
	}
}
