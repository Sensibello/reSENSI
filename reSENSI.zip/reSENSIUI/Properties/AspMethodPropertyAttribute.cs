﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Property)]
	public sealed class AspMethodPropertyAttribute : Attribute
	{
	}
}
