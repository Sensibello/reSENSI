﻿using System;

namespace reSENSIUI.Properties
{
	[AttributeUsage(AttributeTargets.Method)]
	public sealed class SourceTemplateAttribute : Attribute
	{
	}
}
