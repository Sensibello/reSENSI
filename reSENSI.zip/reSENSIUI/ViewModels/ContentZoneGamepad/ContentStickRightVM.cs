﻿using System;
using Prism.Ioc;
using reSENSIUI.ViewModels.Base;

namespace reSENSIUI.ViewModels.ContentZoneGamepad
{
	public class ContentStickRightVM : BaseKeyBindVM
	{
		public ContentStickRightVM(IContainerProvider uc)
			: base(uc)
		{
		}
	}
}
