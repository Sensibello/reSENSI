﻿using System;
using Prism.Ioc;
using reSENSIUI.ViewModels.Base;

namespace reSENSIUI.ViewModels.ContentZoneGamepad
{
	public class ContentDPADVM : BaseKeyBindVM
	{
		public ContentDPADVM(IContainerProvider uc)
			: base(uc)
		{
		}
	}
}
