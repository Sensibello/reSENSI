﻿using System;
using Prism.Ioc;
using reSENSIUI.ViewModels.Base;

namespace reSENSIUI.ViewModels.ContentZoneGamepad
{
	public class ContentStickLeftVM : BaseKeyBindVM
	{
		public ContentStickLeftVM(IContainerProvider uc)
			: base(uc)
		{
		}
	}
}
