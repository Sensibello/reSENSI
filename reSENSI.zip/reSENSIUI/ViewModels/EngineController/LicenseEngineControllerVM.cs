﻿using System;
using Prism.Ioc;

namespace reSENSIUI.ViewModels.EngineController
{
	public class LicenseEngineControllerVM : BaseEngineControllerVM
	{
		public LicenseEngineControllerVM(IContainerProvider uc)
			: base(uc)
		{
		}
	}
}
